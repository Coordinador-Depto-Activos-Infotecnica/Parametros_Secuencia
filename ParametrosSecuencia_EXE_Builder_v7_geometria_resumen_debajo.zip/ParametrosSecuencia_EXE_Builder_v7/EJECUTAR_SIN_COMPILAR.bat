@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py ParametrosSecuencia.py) || (python ParametrosSecuencia.py)
