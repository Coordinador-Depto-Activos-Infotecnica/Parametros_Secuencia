@echo off
setlocal
cd /d "%~dp0"
title Compilador Parametros de Secuencia

echo ==============================================
echo   GENERADOR ParametrosSecuencia.exe
echo ==============================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo ERROR: Python no esta instalado.
        echo Instale Python 3 desde python.org y marque "Add Python to PATH".
        echo Luego vuelva a ejecutar este archivo.
        pause
        exit /b 1
    )
)

echo [1/3] Verificando Python...
%PY% --version
if errorlevel 1 goto :error

echo.
echo [2/3] Instalando/actualizando PyInstaller...
%PY% -m pip install --upgrade pip pyinstaller reportlab
if errorlevel 1 goto :error

echo.
echo [3/3] Creando ejecutable...
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name ParametrosSecuencia ParametrosSecuencia.py
if errorlevel 1 goto :error

if exist "%~dp0dist\ParametrosSecuencia.exe" (
    echo.
    echo ==============================================
    echo EXITO
    echo Ejecutable creado en:
    echo %~dp0dist\ParametrosSecuencia.exe
    echo ==============================================
    explorer "%~dp0dist"
    pause
    exit /b 0
)

:error
echo.
echo ERROR: No fue posible crear el ejecutable.
echo Revise los mensajes anteriores.
pause
exit /b 1
