import math, csv, json, os, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from dataclasses import dataclass, asdict
from typing import List

MU0 = 1.2566370614e-6
INV_E0 = 17.975109  # 1/(2*pi*eps0), as used by original VBA

@dataclass
class Conductor:
    name: str
    kind: str          # phase | guard
    circuit: int       # 1/2, 0 for guard
    phase: str         # A/B/C or G
    rdc: float         # ohm/km at 20 C
    diameter_mm: float
    rmg_mm: float
    x: float           # m
    h: float           # m
    bundle_n: int = 1
    bundle_spacing_m: float = 0.0

# ---------- matrix helpers (pure Python, complex-capable) ----------
def zeros(r,c): return [[0j for _ in range(c)] for __ in range(r)]
def eye(n):
    a=zeros(n,n)
    for i in range(n): a[i][i]=1+0j
    return a

def matmul(a,b):
    r,k,c=len(a),len(b),len(b[0])
    out=zeros(r,c)
    for i in range(r):
        for t in range(k):
            ait=a[i][t]
            for j in range(c): out[i][j]+=ait*b[t][j]
    return out

def matsub(a,b): return [[a[i][j]-b[i][j] for j in range(len(a[0]))] for i in range(len(a))]

def inverse(a):
    n=len(a); m=[list(map(complex,row))+eye(n)[i] for i,row in enumerate(a)]
    for col in range(n):
        piv=max(range(col,n), key=lambda r: abs(m[r][col]))
        if abs(m[piv][col]) < 1e-18: raise ValueError('Matriz singular; revise geometría y parámetros.')
        m[col],m[piv]=m[piv],m[col]
        d=m[col][col]
        m[col]=[v/d for v in m[col]]
        for r in range(n):
            if r==col: continue
            f=m[r][col]
            if f:
                m[r]=[m[r][j]-f*m[col][j] for j in range(2*n)]
    return [row[n:] for row in m]

def submatrix(a, rows, cols): return [[a[i][j] for j in cols] for i in rows]

def kron_reduce(a, eliminate):
    n=len(a); keep=[i for i in range(n) if i not in eliminate]
    if not eliminate: return submatrix(a, keep, keep)
    app=submatrix(a,keep,keep); ape=submatrix(a,keep,eliminate)
    aep=submatrix(a,eliminate,keep); aee=submatrix(a,eliminate,eliminate)
    return matsub(app, matmul(matmul(ape,inverse(aee)),aep))

def block_diag(mats):
    n=sum(len(x) for x in mats); out=zeros(n,n); off=0
    for a in mats:
        for i in range(len(a)):
            for j in range(len(a)): out[off+i][off+j]=a[i][j]
        off += len(a)
    return out

# ---------- electrical model ----------
def effective_radius(c: Conductor):
    """Radio físico equivalente del haz [m], usado por la parte capacitiva."""
    r = c.diameter_mm/(2*1000.0)
    n=max(1,int(c.bundle_n)); d=float(c.bundle_spacing_m or 0)
    if n==2 and d>0: return (r*d)**0.5
    if n==3 and d>0: return (r*d**2)**(1/3)
    if n==4 and d>0: return (math.sqrt(2)*r*d**3)**0.25
    return r

def equivalent_gmr(c: Conductor):
    """RMG equivalente del haz [m].

    Mantiene el RMG individual como dato de entrada y calcula el RMG del conjunto
    según la disposición simétrica usada por el VBA para 2, 3 y 4 subconductores.
    """
    g = c.rmg_mm/1000.0
    n=max(1,int(c.bundle_n)); d=float(c.bundle_spacing_m or 0)
    if g <= 0:
        raise ValueError(f'RMG inválido en {c.name}.')
    if n == 1:
        return g
    if d <= 0:
        raise ValueError(f'La separación del haz debe ser mayor que cero en {c.name}.')
    if n==2: return (g*d)**0.5
    if n==3: return (g*d**2)**(1/3)
    if n==4: return (math.sqrt(2)*g*d**3)**0.25
    raise ValueError('El número de subconductores debe ser 1, 2, 3 o 4.')

def skin_adjust(c: Conductor, freq):
    base_r = c.diameter_mm/(2*1000.0)
    if c.rmg_mm<=0 or base_r<=0 or c.rdc<=0: raise ValueError(f'Parámetros inválidos en {c.name}.')
    mu_r = -math.log(c.rmg_mm/(base_r*1000.0))*4
    omega=2*math.pi*freq
    shi=math.sqrt((omega*mu_r*MU0*1000)/(c.rdc*math.pi))
    A=1-(1/12)*(shi/2)**4+(1/2880)*(shi/2)**8
    D=(shi/2)**2-(1/36)*(shi/2)**6
    C=1-(1/4)*(shi/2)**4+(1/576)*(shi/2)**8
    B=(1/2)*(shi/2)**2-(1/144)*(shi/2)**6
    den=A*A+B*B
    xint=c.rdc/den*(-C*B+D*A)
    rac=c.rdc/den*(C*A+D*B)
    n=max(1,int(c.bundle_n)); return rac/n, xint/n

def geometry(c1,c2=None):
    if c2 is None:
        d=2*c1.h; phi=0.0
        return d,d,phi
    dx=c1.x-c2.x
    d=math.sqrt(dx*dx+(c1.h-c2.h)**2)
    di=math.sqrt(dx*dx+(c1.h+c2.h)**2)
    if d<=0 or di<=0: raise ValueError('Dos conductores ocupan la misma coordenada.')
    arg=((2*c1.h)**2 + di**2 - d**2)/(2*2*c1.h*di)
    arg=max(-1.0,min(1.0,arg)); phi=math.acos(arg)
    return d,di,phi

def carson(distance_image, phi, rho, freq, mutual):
    omega=2*math.pi*freq
    x=distance_image*math.sqrt(MU0*(1/rho)*omega)
    if x<=0: raise ValueError('La resistividad y alturas deben ser mayores que cero.')
    pi=math.pi
    b1=math.sqrt(2)/6; b2=1/16
    b3=abs(b1)/(3*(3+2)); b4=abs(b2)/(4*(4+2))
    b5=-abs(b1)/(5*(5+2)); b6=-abs(b2)/(6*(6+2))
    b7=-abs(b1)/(7*(7+2)); b8=-abs(b2)/(8*(8+2))
    c2=1.3659315; c4=c2+1/4+1/6; c6=c2+1/6+1/8; c8=c2+1/8+1/10
    d2=pi/4*b2; d4=pi/4*b4; d6=pi/4*b6; d8=pi/4*b8; K=.6159315
    if not mutual:
        P=pi/8 - b1*x + b2*(c2-math.log(x))*x**2 + b3*x**3 - d4*x**4 - b5*x**5 + b6*(c6-math.log(x))*x**6 + b7*x**7 - d8*x**8
        Q=.5*(K-math.log(x)) + b1*x - d2*x**2 + b3*x**3 - b4*(c4-math.log(x))*x**4 + b5*x**5 - d6*x**6 + b7*x**7 - b8*(c8-math.log(x))*x**8
    else:
        P=pi/8 - b1*x*math.cos(phi) + b2*((c2-math.log(x))*math.cos(2*phi)+phi*math.sin(2*phi))*x**2 + b3*math.cos(3*phi)*x**3 - d4*math.cos(4*phi)*x**4 - b5*math.cos(5*phi)*x**5 + b6*((c6-math.log(x))*math.cos(6*phi)+phi*math.sin(6*phi))*x**6 + b7*math.cos(7*phi)*x**7 - d8*math.cos(8*phi)*x**8
        Q=.5*(K-math.log(x)) + b1*x*math.cos(phi) - d2*math.cos(2*phi)*x**2 + b3*math.cos(3*phi)*x**3 - b4*((c4-math.log(x))*math.cos(4*phi)+phi*math.sin(4*phi))*x**4 + b5*math.cos(5*phi)*x**5 - d6*math.cos(6*phi)*x**6 + b7*math.cos(7*phi)*x**7 - b8*((c8-math.log(x))*math.cos(8*phi)+phi*math.sin(8*phi))*x**8
    return omega*MU0/pi*P*1000, omega*MU0/pi*Q*1000

def natural_impedance(conductors, rho, freq):
    n=len(conductors); z=zeros(n,n); omega=2*math.pi*freq
    adj=[skin_adjust(c,freq) for c in conductors]
    radii=[effective_radius(c) for c in conductors]
    for i,ci in enumerate(conductors):
        if ci.h<=0: raise ValueError(f'Altura inválida en {ci.name}.')
        for j,cj in enumerate(conductors):
            if j<i: z[i][j]=z[j][i]; continue
            if i==j:
                _,di,phi=geometry(ci)
                re,xe=carson(di,phi,rho,freq,False)
                # Forma explícita con RMG equivalente del haz. La corrección de skin
                # se aplica respecto de la reactancia interna implícita en el RMG individual,
                # evitando contabilizar dos veces el flujo interno. Algebraicamente conserva
                # la formulación VBA de radio equivalente + Xint/n, pero hace visible que el
                # RMG del haz participa directamente en la reactancia propia.
                n_bundle=max(1,int(ci.bundle_n))
                gmr_eq=equivalent_gmr(ci)
                kx=omega*MU0/(2*math.pi)*1000
                r_ind=ci.diameter_mm/(2*1000.0)
                gmr_ind=ci.rmg_mm/1000.0
                xint_ref=(kx*math.log(r_ind/gmr_ind))/n_bundle
                xg=kx*math.log(2*ci.h/gmr_eq)
                rac,xint=adj[i]
                val=(rac+re)+1j*((xint-xint_ref)+xg+xe)
            else:
                d,di,phi=geometry(ci,cj)
                re,xe=carson(di,phi,rho,freq,True)
                xg=omega*MU0/(2*math.pi)*math.log(di/d)*1000
                val=re+1j*(xg+xe)
            z[i][j]=val; z[j][i]=val
    return z

def potential_matrix(conductors):
    n=len(conductors); p=zeros(n,n); radii=[effective_radius(c) for c in conductors]
    for i,ci in enumerate(conductors):
        for j,cj in enumerate(conductors):
            if j<i: p[i][j]=p[j][i]; continue
            if i==j: val=INV_E0*math.log(2*ci.h/radii[i])
            else:
                d,di,_=geometry(ci,cj); val=INV_E0*math.log(di/d)
            p[i][j]=val; p[j][i]=val
    return p

def sequence_transform(m, circuits):
    a=complex(-.5, math.sqrt(3)/2)
    S=[[1+0j,1+0j,1+0j],[1+0j,a,a.conjugate()],[1+0j,a.conjugate(),a]]
    T=[[v.conjugate()/3 for v in row] for row in S]
    Sb=block_diag([S]*circuits); Tb=block_diag([T]*circuits)
    return matmul(matmul(Sb,m),Tb)

def calculate(conductors: List[Conductor], rho=100.0, freq=50.0):
    phases=[c for c in conductors if c.kind=='phase']
    guards=[c for c in conductors if c.kind=='guard']
    circuits=max((c.circuit for c in phases), default=1)
    ordered=[]
    for g in guards: ordered.append(g)
    for circuit in range(1,circuits+1):
        for ph in ('A','B','C'):
            found=[c for c in phases if c.circuit==circuit and c.phase.upper()==ph]
            if len(found)!=1: raise ValueError(f'Circuito {circuit}: debe existir exactamente una fase {ph}.')
            ordered.append(found[0])
    gcount=len(guards)
    z=natural_impedance(ordered,rho,freq)
    zred=kron_reduce(z,list(range(gcount)))
    zseq=sequence_transform(zred,circuits)
    p=potential_matrix(ordered)
    pred=kron_reduce(p,list(range(gcount)))
    cred=inverse(pred)
    omega=2*math.pi*freq
    bred=[[omega*cred[i][j] for j in range(len(cred))] for i in range(len(cred))]
    bseq=sequence_transform(bred,circuits)
    return {'ordered':ordered,'Z_natural':z,'Z_reduced':zred,'Z_sequence':zseq,'P_natural':p,'P_reduced':pred,'C_reduced':cred,'B_reduced':bred,'B_sequence':bseq,'guard_count':gcount,'circuits':circuits,'rho':rho,'freq':freq}

EXAMPLE_RHO={'1 circuito / 0 CG':600,'1 circuito / 1 CG':600,'1 circuito / 2 CG':600,'2 circuitos / 0 CG':600,'2 circuitos / 1 CG':164.9,'2 circuitos / 2 CG':100}

EXAMPLES={
'1 circuito / 0 CG': [
 Conductor('Fase A','phase',1,'A',.101,23.53,8.92,4.7,27.673),
 Conductor('Fase B','phase',1,'B',.101,23.53,8.92,-5.2,21.473),
 Conductor('Fase C','phase',1,'C',.101,23.53,8.92,4.85,15.273)],
'1 circuito / 1 CG': [
 Conductor('CG1','guard',0,'G',.674,11.7,4.556,0,33),
 Conductor('Fase A','phase',1,'A',.101,23.53,8.92,4.7,27.673),
 Conductor('Fase B','phase',1,'B',.101,23.53,8.92,-5.2,21.473),
 Conductor('Fase C','phase',1,'C',.101,23.53,8.92,4.85,15.273)],
'1 circuito / 2 CG': [
 Conductor('CG1','guard',0,'G',.674,11.7,4.556,3,33), Conductor('CG2','guard',0,'G',.674,11.7,4.556,-3,33),
 Conductor('Fase A','phase',1,'A',.101,23.53,8.92,4.7,27.673),
 Conductor('Fase B','phase',1,'B',.101,23.53,8.92,-5.2,21.473),
 Conductor('Fase C','phase',1,'C',.101,23.53,8.92,4.85,15.273)],
'2 circuitos / 0 CG': [
 Conductor('C1-A','phase',1,'A',.101,23.53,8.92,4.7,27.673), Conductor('C1-B','phase',1,'B',.101,23.53,8.92,5.2,21.473), Conductor('C1-C','phase',1,'C',.101,23.53,8.92,4.85,15.273),
 Conductor('C2-A','phase',2,'A',.0892,25.16,9.66,-4.7,26.427), Conductor('C2-B','phase',2,'B',.0892,25.16,9.66,-5.2,20.227), Conductor('C2-C','phase',2,'C',.0892,25.16,9.66,-4.85,14.027)],
'2 circuitos / 1 CG': [
 Conductor('CG1','guard',0,'G',.69,12.1,4.712,0,30),
 Conductor('C1-A','phase',1,'A',.06299,27.74,10.652,4.7,27.673), Conductor('C1-B','phase',1,'B',.06299,27.74,10.652,5.2,21.473), Conductor('C1-C','phase',1,'C',.06299,27.74,10.652,4.85,15.273),
 Conductor('C2-A','phase',2,'A',.06299,27.74,10.652,-4.7,26.427), Conductor('C2-B','phase',2,'B',.06299,27.74,10.652,-5.2,20.227), Conductor('C2-C','phase',2,'C',.06299,27.74,10.652,-4.85,14.027)],
'2 circuitos / 2 CG': [
 Conductor('CG1','guard',0,'G',.674,11.7,4.556,-2,30), Conductor('CG2','guard',0,'G',.537,13.56,5.253,2,30),
 Conductor('C1-A','phase',1,'A',.101,23.53,8.92,4.7,27.673), Conductor('C1-B','phase',1,'B',.101,23.53,8.92,5.2,21.473), Conductor('C1-C','phase',1,'C',.101,23.53,8.92,4.85,15.273),
 Conductor('C2-A','phase',2,'A',.0892,25.16,9.66,-4.7,26.427), Conductor('C2-B','phase',2,'B',.0892,25.16,9.66,-5.2,20.227), Conductor('C2-C','phase',2,'C',.0892,25.16,9.66,-4.85,14.027)]
}

class App(tk.Tk):
    cols=['name','kind','circuit','phase','rdc','diameter_mm','rmg_mm','x','h','bundle_n','bundle_spacing_m']
    labels=['Nombre','Tipo','Cto','Fase','Rdc Ω/km','Diám. mm','RMG ind. mm','RMG haz mm*','x m','y/h m','Subcond.*','Sep. m*']
    def __init__(self):
        super().__init__(); self.title('Parámetros de Secuencia - Líneas Aéreas (v7)'); self.geometry('1320x760'); self.minsize(1180,650)
        self.entries=[]; self.last=None
        top=ttk.Frame(self,padding=10); top.pack(fill='x')
        ttk.Label(top,text='Configuración:').pack(side='left'); self.example=tk.StringVar(value='1 circuito / 0 CG')
        cb=ttk.Combobox(top,textvariable=self.example,values=list(EXAMPLES),state='readonly',width=24); cb.pack(side='left',padx=6); cb.bind('<<ComboboxSelected>>',lambda e:self.load_example())
        ttk.Label(top,text='ρ terreno Ω·m').pack(side='left',padx=(18,4)); self.rho=tk.StringVar(value='600'); ttk.Entry(top,textvariable=self.rho,width=9).pack(side='left')
        ttk.Label(top,text='Frecuencia Hz').pack(side='left',padx=(18,4)); self.freq=tk.StringVar(value='50'); ttk.Entry(top,textvariable=self.freq,width=7).pack(side='left')
        ttk.Button(top,text='Calcular',command=self.run_calc).pack(side='right',padx=4); ttk.Button(top,text='Reporte PDF',command=self.export_pdf).pack(side='right',padx=4); ttk.Button(top,text='Exportar CSV',command=self.export_csv).pack(side='right',padx=4); ttk.Button(top,text='Guardar proyecto',command=self.save_project).pack(side='right',padx=4); ttk.Button(top,text='Abrir proyecto',command=self.open_project).pack(side='right',padx=4)

        # Parámetros de conductores en haz, visibles y separados por circuito.
        # Replica la lógica de Guía de uso: B12/B15 + separaciones de cada circuito.
        bundle=ttk.LabelFrame(self,text='Conductores en haz',padding=(10,6)); bundle.pack(fill='x',padx=10,pady=(0,6))
        self.bundle_n1=tk.StringVar(value='1'); self.bundle_d1=tk.StringVar(value='0.45')
        self.bundle_n2=tk.StringVar(value='1'); self.bundle_d2=tk.StringVar(value='0.45')
        ttk.Label(bundle,text='Circuito 1 - subconductores:').pack(side='left')
        ttk.Combobox(bundle,textvariable=self.bundle_n1,values=['1','2','3','4'],state='readonly',width=4).pack(side='left',padx=(4,8))
        ttk.Label(bundle,text='Separación [m]:').pack(side='left')
        ttk.Entry(bundle,textvariable=self.bundle_d1,width=8).pack(side='left',padx=(4,18))
        ttk.Label(bundle,text='Circuito 2 - subconductores:').pack(side='left')
        self.bundle2_combo=ttk.Combobox(bundle,textvariable=self.bundle_n2,values=['1','2','3','4'],state='readonly',width=4)
        self.bundle2_combo.pack(side='left',padx=(4,8))
        ttk.Label(bundle,text='Separación [m]:').pack(side='left')
        self.bundle2_sep=ttk.Entry(bundle,textvariable=self.bundle_d2,width=8); self.bundle2_sep.pack(side='left',padx=(4,8))
        ttk.Label(bundle,text='(si hay 1 subconductor, la separación no interviene)').pack(side='left',padx=(10,0))

        self.gridf=ttk.Frame(self,padding=(10,0)); self.gridf.pack(fill='x'); self.draw_table(EXAMPLES[self.example.get()]); self.update_bundle_controls()
        # Sincroniza inmediatamente los controles superiores con las columnas Subcond./Sep.
        # De esta forma lo que ve el usuario en la tabla es exactamente lo que usará el cálculo.
        for var in (self.bundle_n1, self.bundle_d1, self.bundle_n2, self.bundle_d2):
            var.trace_add('write', self._bundle_changed)
        self.sync_bundle_columns()
        self.nb=ttk.Notebook(self); self.nb.pack(fill='both',expand=True,padx=10,pady=10)
        self.texts={}
        for key,title in [('summary','Resultados clave'),('seq','Impedancia de secuencia Z012'),('red','Impedancia reducida Zabc'),('bseq','Susceptancia de secuencia')]:
            f=ttk.Frame(self.nb); self.nb.add(f,text=title); t=tk.Text(f,font=('Consolas',10),wrap='none'); t.pack(fill='both',expand=True); self.texts[key]=t

        # Hoja de auditoría: fórmulas y matrices intermedias del desarrollo completo.
        f=ttk.Frame(self.nb); self.nb.add(f,text='Desarrollo de cálculos')
        t=tk.Text(f,font=('Consolas',9),wrap='none'); t.pack(fill='both',expand=True); self.texts['development']=t

        # Hoja gráfica de geometría de la estructura. Muestra coordenadas, circuitos,
        # cables de guarda y representación visible de los subconductores del haz.
        self.geometry_frame=ttk.Frame(self.nb); self.nb.add(self.geometry_frame,text='Geometría de la estructura')
        self.geometry_pane=ttk.Panedwindow(self.geometry_frame,orient='horizontal'); self.geometry_pane.pack(fill='both',expand=True)
        self.geometry_canvas=tk.Canvas(self.geometry_pane,background='white',highlightthickness=0)
        self.geometry_info=tk.Text(self.geometry_pane,font=('Consolas',9),wrap='none',width=54)
        self.geometry_pane.add(self.geometry_canvas,weight=3); self.geometry_pane.add(self.geometry_info,weight=2)
        self.geometry_canvas.bind('<Configure>',lambda e:self.after_idle(self.redraw_geometry))

        f=ttk.Frame(self.nb); self.nb.add(f,text='Notas'); t=tk.Text(f,font=('Consolas',10),wrap='none'); t.pack(fill='both',expand=True); self.texts['notes']=t
        self.texts['notes'].insert('1.0','Aplicación independiente de Excel.\nMotor basado en las ecuaciones Carson/Fortescue del VBA original.\nUnidades: impedancias Ω/km; susceptancia según la escala del modelo original.\nLos campos superiores Conductores en haz se aplican por circuito y las columnas Subcond./Sep. se actualizan inmediatamente.\nLa columna RMG haz mm se recalcula automáticamente desde el RMG individual y la separación: n=2 sqrt(GMR*d), n=3 (GMR*d^2)^(1/3), n=4 (sqrt(2)*GMR*d^3)^(1/4).\nLa hoja Geometría de la estructura muestra la posición x/h de cada conductor, el circuito, la fase, los cables de guarda y una representación del haz de subconductores.\n')
        self.geometry_conductors=[]
    def draw_table(self, conductors):
        for w in self.gridf.winfo_children(): w.destroy()
        self.entries=[]
        for j,l in enumerate(self.labels): ttk.Label(self.gridf,text=l).grid(row=0,column=j,padx=2,pady=2,sticky='ew')
        for i,c in enumerate(conductors,1):
            row=[]; data=asdict(c)
            # Siete primeras entradas hasta RMG individual
            for j,k in enumerate(self.cols[:7]):
                v=data[k]; e=ttk.Entry(self.gridf,width=11 if j else 13); e.insert(0,str(v)); e.grid(row=i,column=j,padx=2,pady=2,sticky='ew'); row.append(e)
                if k in ('rmg_mm','diameter_mm'):
                    e.bind('<KeyRelease>', lambda ev: self.after_idle(self.sync_bundle_columns))
                    e.bind('<FocusOut>', lambda ev: self.after_idle(self.sync_bundle_columns))
            # Columna derivada de RMG equivalente del haz: solo lectura
            eq=ttk.Entry(self.gridf,width=11,state='readonly'); eq.grid(row=i,column=7,padx=2,pady=2,sticky='ew'); row.append(eq)
            # x, h, bundle_n, bundle_spacing_m
            for ui_j,k in enumerate(self.cols[7:], start=8):
                v=data[k]; e=ttk.Entry(self.gridf,width=11); e.insert(0,str(v)); e.grid(row=i,column=ui_j,padx=2,pady=2,sticky='ew'); row.append(e)
            self.entries.append(row)
        self.after_idle(self.sync_bundle_columns)
    def load_example(self):
        self.draw_table(EXAMPLES[self.example.get()]); self.rho.set(str(EXAMPLE_RHO.get(self.example.get(),600)))
        self.bundle_n1.set('1'); self.bundle_d1.set('0.45'); self.bundle_n2.set('1'); self.bundle_d2.set('0.45')
        self.update_bundle_controls(); self.sync_bundle_columns()
    def update_bundle_controls(self):
        two = self.example.get().startswith('2 circuitos')
        self.bundle2_combo.configure(state='readonly' if two else 'disabled')
        self.bundle2_sep.configure(state='normal' if two else 'disabled')

    def _bundle_changed(self, *args):
        # Los trace se disparan también mientras se está escribiendo 0.45; por eso
        # la sincronización tolera temporalmente campos incompletos.
        self.after_idle(self.sync_bundle_columns)

    def sync_bundle_columns(self):
        if not getattr(self, 'entries', None):
            return
        try:
            n1 = int(float(self.bundle_n1.get().replace(',','.')))
            d1 = float(self.bundle_d1.get().replace(',','.'))
            n2 = int(float(self.bundle_n2.get().replace(',','.')))
            d2 = float(self.bundle_d2.get().replace(',','.'))
        except (ValueError, AttributeError):
            return
        for row in self.entries:
            try:
                kind = row[1].get().strip().lower()
                circuit = int(float(row[2].get().strip().replace(',','.')))
                rmg_ind = float(row[6].get().strip().replace(',','.'))
            except Exception:
                continue
            if kind == 'phase' and circuit == 1:
                n, d = n1, (d1 if n1 > 1 else 0.0)
            elif kind == 'phase' and circuit == 2:
                n, d = n2, (d2 if n2 > 1 else 0.0)
            else:
                n, d = 1, 0.0
            # UI indices: 7=RMG haz, 10=Subcond., 11=Sep.
            row[10].delete(0, 'end'); row[10].insert(0, str(n))
            row[11].delete(0, 'end'); row[11].insert(0, str(d))
            try:
                temp=Conductor('tmp',kind,circuit,row[3].get(),1,1,rmg_ind,0,1,n,d)
                gmm=equivalent_gmr(temp)*1000.0
                row[7].configure(state='normal'); row[7].delete(0,'end'); row[7].insert(0,f'{gmm:.6f}'); row[7].configure(state='readonly')
            except Exception:
                row[7].configure(state='normal'); row[7].delete(0,'end'); row[7].configure(state='readonly')

    def apply_bundle_settings(self, cs):
        n1=int(float(self.bundle_n1.get().replace(',','.'))); d1=float(self.bundle_d1.get().replace(',','.'))
        n2=int(float(self.bundle_n2.get().replace(',','.'))); d2=float(self.bundle_d2.get().replace(',','.'))
        if n1 not in (1,2,3,4) or n2 not in (1,2,3,4): raise ValueError('El número de subconductores debe ser 1, 2, 3 o 4.')
        if n1>1 and d1<=0: raise ValueError('La separación del haz del circuito 1 debe ser mayor que cero.')
        if n2>1 and d2<=0: raise ValueError('La separación del haz del circuito 2 debe ser mayor que cero.')
        for c in cs:
            if c.kind=='phase' and c.circuit==1:
                c.bundle_n=n1; c.bundle_spacing_m=d1 if n1>1 else 0.0
            elif c.kind=='phase' and c.circuit==2:
                c.bundle_n=n2; c.bundle_spacing_m=d2 if n2>1 else 0.0
        return cs
    def add_row(self):
        cs=self.read_rows(silent=True); cs.append(Conductor('Nuevo','phase',1,'A',.1,20,8,0,20)); self.draw_table(cs)
    def del_row(self):
        cs=self.read_rows(silent=True)
        if cs: cs.pop(); self.draw_table(cs)
    def read_rows(self,silent=False):
        out=[]
        try:
            for row in self.entries:
                # UI: 0 name,1 kind,2 cto,3 fase,4 rdc,5 diam,6 RMG individual,
                # 7 RMG equivalente (derivado),8 x,9 h,10 n,11 separación
                v=[x.get().strip().replace(',','.') for x in row]
                out.append(Conductor(v[0],v[1].lower(),int(float(v[2])),v[3].upper(),float(v[4]),float(v[5]),float(v[6]),float(v[8]),float(v[9]),int(float(v[10])),float(v[11] or 0)))
            return out
        except Exception as e:
            if not silent: messagebox.showerror('Datos inválidos',str(e))
            return []
    def fmt_matrix(self,m,title):
        s=title+'\n'+'='*len(title)+'\n'
        for row in m:
            s+='  '.join(f'{v.real: .8f} {v.imag:+.8f}j' for v in row)+'\n'
        return s
    def bundle_offsets_px(self, n, radius_px=7):
        """Desplazamientos gráficos del haz. El símbolo no está a escala física."""
        n=max(1,int(n))
        if n==1: return [(0,0)]
        if n==2: return [(-radius_px,0),(radius_px,0)]
        if n==3:
            return [(0,-radius_px),(-0.866*radius_px,0.5*radius_px),(0.866*radius_px,0.5*radius_px)]
        if n==4: return [(-radius_px,-radius_px),(radius_px,-radius_px),(-radius_px,radius_px),(radius_px,radius_px)]
        return [(0,0)]

    def redraw_geometry(self):
        if not hasattr(self,'geometry_canvas'): return
        cv=self.geometry_canvas; cv.delete('all')
        cs=getattr(self,'geometry_conductors',None) or []
        if not cs:
            cv.create_text(20,20,anchor='nw',text='Ejecute Calcular para visualizar la geometría de la estructura.',font=('TkDefaultFont',11))
            return
        w=max(500,cv.winfo_width()); h=max(350,cv.winfo_height())
        margin_l,margin_r,margin_t,margin_b=60,40,35,45
        xs=[c.x for c in cs]; hs=[c.h for c in cs]
        xmin=min(xs); xmax=max(xs); hmax=max(hs)
        xpad=max(1.5,(xmax-xmin)*0.15 if xmax>xmin else 3.0)
        xmin-=xpad; xmax+=xpad; ymax=max(5.0,hmax*1.12)
        sx=(w-margin_l-margin_r)/(xmax-xmin)
        sy=(h-margin_t-margin_b)/ymax
        def X(x): return margin_l+(x-xmin)*sx
        def Y(y): return h-margin_b-y*sy
        ground=Y(0)
        cv.create_line(margin_l,ground,w-margin_r,ground,width=2)
        cv.create_text(w-margin_r,ground+20,anchor='e',text='x [m]')
        cv.create_line(X(0),ground,X(0),margin_t,dash=(4,3))
        cv.create_text(X(0)+5,margin_t,anchor='nw',text='eje x=0')
        # Escala vertical simple
        for yy in range(0,int(ymax)+1,5):
            py=Y(yy); cv.create_line(margin_l-4,py,margin_l,py); cv.create_text(margin_l-7,py,anchor='e',text=str(yy),font=('TkDefaultFont',8))
        cv.create_text(12,margin_t,anchor='nw',text='h [m]')

        # Une las tres fases de cada circuito para hacer visible la estructura/circuito.
        for cto in sorted({c.circuit for c in cs if c.kind=='phase'}):
            pts=[]
            for ph in ('A','B','C'):
                matches=[c for c in cs if c.kind=='phase' and c.circuit==cto and c.phase.upper()==ph]
                if matches: pts.append((X(matches[0].x),Y(matches[0].h)))
            if len(pts)>=2:
                flat=[v for p in pts for v in p]; cv.create_line(*flat,dash=(2,3),width=1)

        for c in cs:
            cx,cy=X(c.x),Y(c.h)
            is_guard=(c.kind=='guard')
            if is_guard:
                r=5; cv.create_oval(cx-r,cy-r,cx+r,cy+r,fill='white',width=2)
                label=f'{c.name} / CG'
            else:
                offs=self.bundle_offsets_px(c.bundle_n,7)
                for ox,oy in offs:
                    r=4; cv.create_oval(cx+ox-r,cy+oy-r,cx+ox+r,cy+oy+r,fill='white',width=2)
                # círculo exterior punteado cuando hay haz, para remarcar el conjunto
                if c.bundle_n>1:
                    rr=15; cv.create_oval(cx-rr,cy-rr,cx+rr,cy+rr,dash=(2,2))
                label=f'C{c.circuit}-{c.phase}  n={c.bundle_n}'
            cv.create_text(cx+11,cy-12,anchor='sw',text=label,font=('TkDefaultFont',9,'bold'))
            cv.create_text(cx+11,cy+3,anchor='nw',text=f'x={c.x:.3f}  h={c.h:.3f} m',font=('TkDefaultFont',8))

        cv.create_text(10,h-10,anchor='sw',text='Nota: el tamaño/separación gráfica del haz está exagerado para hacerlo visible; las coordenadas x/h sí se representan a escala.',font=('TkDefaultFont',8))

    def update_geometry_sheet(self, cs):
        self.geometry_conductors=[Conductor(**asdict(c)) for c in cs]
        self.redraw_geometry()
        lines=['GEOMETRÍA DE LA ESTRUCTURA','==========================','',
               'Las coordenadas x/h están en metros. El símbolo del haz no está a escala.','']
        hdr=f"{'Nombre':<13} {'Tipo':<7} {'Cto':>3} {'Fase':>4} {'x [m]':>10} {'h [m]':>10} {'n':>3} {'Sep [m]':>10} {'RMG ind [mm]':>13} {'RMG haz [mm]':>13}"
        lines += [hdr,'-'*len(hdr)]
        for c in cs:
            try: gh=equivalent_gmr(c)*1000.0
            except Exception: gh=float('nan')
            lines.append(f"{c.name:<13.13} {c.kind:<7.7} {c.circuit:>3} {c.phase:>4.4} {c.x:>10.3f} {c.h:>10.3f} {c.bundle_n:>3} {c.bundle_spacing_m:>10.4f} {c.rmg_mm:>13.5f} {gh:>13.5f}")
        lines += ['','CIRCUITOS']
        for cto in sorted({c.circuit for c in cs if c.kind=='phase'}):
            phases=[c for c in cs if c.kind=='phase' and c.circuit==cto]
            n=phases[0].bundle_n if phases else 1; d=phases[0].bundle_spacing_m if phases else 0
            lines.append(f'Circuito {cto}: {n} subconductor(es) por fase; separación del haz = {d:.4f} m')
        guards=[c for c in cs if c.kind=='guard']
        lines.append(f'Cables de guarda: {len(guards)}')
        self.geometry_info.delete('1.0','end'); self.geometry_info.insert('1.0','\n'.join(lines))

    def fmt_real_matrix(self,m,title,unit=''):
        s=title + (f' [{unit}]' if unit else '') + '\n' + '='*len(title) + '\n'
        for row in m:
            s += '  '.join(f'{complex(v).real: .10f}' if abs(complex(v).imag)<1e-14 else f'{complex(v).real: .10f}{complex(v).imag:+.10f}j' for v in row) + '\n'
        return s

    def build_development(self, cs):
        """Genera una hoja de auditoría numérica con fórmulas y matrices intermedias."""
        r=self.last
        if not r: return ''
        rho=float(self.rho.get().replace(',','.')); freq=float(self.freq.get().replace(',','.'))
        omega=2*math.pi*freq
        kx=omega*MU0/(2*math.pi)*1000
        L=[]
        add=L.append
        add('DESARROLLO DE LOS CÁLCULOS')
        add('==========================')
        add('')
        add('OBJETIVO')
        add('Mostrar las ecuaciones y matrices intermedias usadas por el motor para permitir revisión técnica.')
        add('Todas las impedancias se expresan en Ω/km. Coordenadas y distancias geométricas en m.')
        add('')
        add('1) CONSTANTES Y DATOS GLOBALES')
        add('------------------------------')
        add(f'ρ terreno = {rho:.10g} Ω·m')
        add(f'f = {freq:.10g} Hz')
        add(f'ω = 2πf = {omega:.12g} rad/s')
        add(f'μ0 = {MU0:.12g} H/m')
        add(f'kX = ω μ0 /(2π) · 1000 = {kx:.12g} Ω/km')
        add(f'Número de circuitos = {r["circuits"]}; cables de guarda eliminados por Kron = {r["guard_count"]}')
        add('')
        add('2) EQUIVALENTES DE CADA CONDUCTOR / HAZ')
        add('---------------------------------------')
        add('RMG haz:')
        add('  n=1: GMRb = GMR')
        add('  n=2: GMRb = √(GMR·d)')
        add('  n=3: GMRb = (GMR·d²)^(1/3)')
        add('  n=4: GMRb = (√2·GMR·d³)^(1/4)')
        add('Radio capacitivo equivalente: mismas expresiones, sustituyendo GMR por radio físico r=D/2.')
        add('')
        hdr=f"{'Ord':>3} {'Nombre':<13} {'Cto':>3} {'F':>2} {'Rdc':>10} {'Dmm':>9} {'GMRmm':>10} {'n':>2} {'d[m]':>9} {'GMRb[mm]':>12} {'req[mm]':>12} {'Rac':>11} {'Xint/n':>11}"
        add(hdr); add('-'*len(hdr))
        for idx,c in enumerate(r['ordered'],1):
            rac,xint=skin_adjust(c,freq); g=equivalent_gmr(c)*1000; req=effective_radius(c)*1000
            add(f'{idx:>3} {c.name:<13.13} {c.circuit:>3} {c.phase:>2} {c.rdc:>10.6f} {c.diameter_mm:>9.4f} {c.rmg_mm:>10.5f} {c.bundle_n:>2} {c.bundle_spacing_m:>9.5f} {g:>12.6f} {req:>12.6f} {rac:>11.8f} {xint:>11.8f}')
        add('')
        add('3) GEOMETRÍA ENTRE CONDUCTORES')
        add('--------------------------------')
        add('Para i≠j: D_ij = √[(xi-xj)² + (hi-hj)²]')
        add("            D'_ij = √[(xi-xj)² + (hi+hj)²]  (distancia al conductor imagen)")
        add("            Xgeom,ij = kX · ln(D'_ij / D_ij)")
        add('Para i=j: Dii imagen = 2hi; la reactancia propia usa GMR equivalente del haz.')
        add('')
        add(f"{'i-j':>7} {'D real [m]':>14} {'D imagen [m]':>16} {'phi [rad]':>13}")
        add('-'*55)
        ordered=r['ordered']
        for i,ci in enumerate(ordered):
            for j in range(i,len(ordered)):
                cj=ordered[j]
                d,di,phi=geometry(ci,None if i==j else cj)
                add(f'{i+1:>3}-{j+1:<3} {d:>14.7f} {di:>16.7f} {phi:>13.8f}')
        add('')
        add('4) CORRECCIÓN DE CARSON')
        add('-----------------------')
        add('x = D_imagen · √(μ0 · (1/ρ) · ω)')
        add('ΔR = (ω μ0 / π) · P · 1000')
        add('ΔX = (ω μ0 / π) · Q · 1000')
        add('P y Q se evalúan mediante las series de Carson implementadas en el motor (hasta término x^8).')
        add('')
        add('5) MATRIZ NATURAL DE IMPEDANCIAS')
        add('---------------------------------')
        add('Diagonal i=i:')
        add('  Zii = (Rac + ΔRcarson) + j[(Xint - Xint_ref) + kX·ln(2hi/GMRb) + ΔXcarson]')
        add('  Xint_ref = [kX·ln(r_ind/GMR_ind)] / n')
        add('Fuera de diagonal i≠j:')
        add("  Zij = ΔRcarson + j[kX·ln(D'_ij/D_ij) + ΔXcarson]")
        add('')
        add(self.fmt_matrix(r['Z_natural'],'Z natural [Ω/km]').rstrip())
        add('')
        add('6) REDUCCIÓN DE KRON PARA CABLES DE GUARDA')
        add('-------------------------------------------')
        add('Partición: Z = [[Zee, Zep],[Zpe, Zpp]] donde e = elementos eliminados (guardas).')
        add('Zred = Zpp - Zpe · inv(Zee) · Zep')
        add('Si no hay cables de guarda, Zred = Zpp = Z natural de las fases.')
        add('')
        add(self.fmt_matrix(r['Z_reduced'],'Z reducida de fases [Ω/km]').rstrip())
        add('')
        add('7) TRANSFORMACIÓN DE FORTESCUE')
        add('--------------------------------')
        add('a = -1/2 + j√3/2')
        add('S = [[1,1,1],[1,a,a²],[1,a²,a]]')
        add('T = conjugada(S) / 3 = S⁻¹')
        add('Para varios circuitos se forman S y T en bloques diagonales.')
        add('Z012 = S_block · Zred · T_block')
        add('')
        a=complex(-.5,math.sqrt(3)/2)
        S=[[1+0j,1+0j,1+0j],[1+0j,a,a.conjugate()],[1+0j,a.conjugate(),a]]
        T=[[v.conjugate()/3 for v in row] for row in S]
        add(self.fmt_matrix(S,'Matriz S').rstrip()); add(''); add(self.fmt_matrix(T,'Matriz T').rstrip()); add('')
        add(self.fmt_matrix(r['Z_sequence'],'Z012 [Ω/km]').rstrip())
        add('')
        add('8) MATRIZ DE COEFICIENTES DE POTENCIAL / CAPACITANCIA')
        add('--------------------------------------------------------')
        add('Diagonal: Pii = 17.975109 · ln(2hi / req_i)')
        add("Mutua:    Pij = 17.975109 · ln(D'_ij / D_ij)")
        add('Se aplica reducción de Kron a P si existen cables de guarda:')
        add('Pred = Ppp - Ppe · inv(Pee) · Pep')
        add('Cred = inv(Pred)')
        add('Bred = ω · Cred')
        add('B012 = S_block · Bred · T_block')
        add('')
        add(self.fmt_real_matrix(r['P_natural'],'P natural').rstrip()); add('')
        add(self.fmt_real_matrix(r['P_reduced'],'P reducida').rstrip()); add('')
        add(self.fmt_real_matrix(r['C_reduced'],'C reducida').rstrip()); add('')
        add(self.fmt_real_matrix(r['B_reduced'],'B reducida').rstrip()); add('')
        add(self.fmt_matrix(r['B_sequence'],'B012').rstrip())
        add('')
        add('9) RESULTADOS DE SECUENCIA EXTRAÍDOS')
        add('------------------------------------')
        for cto in range(r['circuits']):
            i0=cto*3; i1=i0+1; zq=r['Z_sequence']; bq=r['B_sequence']
            add(f'Circuito {cto+1}:')
            add(f'  Z0 = {zq[i0][i0].real:.12f} {zq[i0][i0].imag:+.12f}j Ω/km')
            add(f'  Z1 = {zq[i1][i1].real:.12f} {zq[i1][i1].imag:+.12f}j Ω/km')
            add(f'  B0 = {bq[i0][i0].real:.12f}')
            add(f'  B1 = {bq[i1][i1].real:.12f}')
        add('')
        add('NOTA DE AUDITORÍA')
        add('Esta hoja documenta exactamente las fórmulas implementadas en esta versión del motor.')
        add('Sirve para comparar cada matriz intermedia con el VBA/Excel y localizar diferencias numéricas.')
        return '\n'.join(L)

    def run_calc(self):
        try:
            self.sync_bundle_columns()
            cs=self.read_rows();
            if not cs: return
            cs=self.apply_bundle_settings(cs)
            self.last=calculate(cs,float(self.rho.get().replace(',','.')),float(self.freq.get().replace(',','.')))
            self.update_geometry_sheet(cs)
            self.texts['development'].delete('1.0','end'); self.texts['development'].insert('1.0',self.build_development(cs))
            zq=self.last['Z_sequence']; bq=self.last['B_sequence']; circuits=len(zq)//3
            lines=['RESULTADOS PRINCIPALES','======================','']
            lines += ['CONDUCTORES EN HAZ']
            for c in cs:
                if c.kind=='phase' and c.phase.upper()=='A':
                    lines += [f'  Circuito {c.circuit}: {c.bundle_n} subconductor(es), separación = {c.bundle_spacing_m:.6f} m, RMG ind. = {c.rmg_mm:.6f} mm, RMG haz = {equivalent_gmr(c)*1000:.6f} mm']
            lines += ['']
            for c in range(circuits):
                i0=c*3; i1=i0+1
                lines += [f'Circuito {c+1}',f'  R1 = {zq[i1][i1].real:.9f} Ω/km',f'  X1 = {zq[i1][i1].imag:.9f} Ω/km',f'  B1 = {bq[i1][i1].real:.9f} µS/km',f'  R0 = {zq[i0][i0].real:.9f} Ω/km',f'  X0 = {zq[i0][i0].imag:.9f} Ω/km',f'  B0 = {bq[i0][i0].real:.9f} µS/km','']
            self.texts['summary'].delete('1.0','end'); self.texts['summary'].insert('1.0','\n'.join(lines))
            self.texts['seq'].delete('1.0','end'); self.texts['seq'].insert('1.0',self.fmt_matrix(self.last['Z_sequence'],'Z012 [Ω/km]'))
            self.texts['red'].delete('1.0','end'); self.texts['red'].insert('1.0',self.fmt_matrix(self.last['Z_reduced'],'Zabc reducida [Ω/km]'))
            self.texts['bseq'].delete('1.0','end'); self.texts['bseq'].insert('1.0',self.fmt_matrix(self.last['B_sequence'],'B012 [µS/km]'))
            self.nb.select(0)
        except Exception as e: messagebox.showerror('Error de cálculo',str(e))
    def export_pdf(self):
        """Genera un informe PDF con todas las pestañas visibles de resultados."""
        if not self.last:
            self.run_calc()
        if not self.last:
            return
        path=filedialog.asksaveasfilename(defaultextension='.pdf',filetypes=[('Documento PDF','*.pdf')],title='Guardar reporte PDF')
        if not path:
            return
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.enums import TA_CENTER
            from reportlab.lib.units import mm
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted, Table, TableStyle, KeepTogether
            from reportlab.pdfbase.ttfonts import TTFont
            from reportlab.pdfbase import pdfmetrics
            from reportlab.platypus import Flowable

            class GeometryFlowable(Flowable):
                # Reproduce en el PDF la misma lectura gráfica de la pestaña del programa:
                # escala h, eje x=0, unión A-B-C, símbolos de haz y etiquetas x/h.
                def __init__(self, conductors, width=158*mm, height=132*mm):
                    Flowable.__init__(self); self.conductors=conductors; self.width=width; self.height=height
                def draw(self):
                    c=self.canv; cs=self.conductors
                    if not cs: return
                    import math as _m
                    xs=[d.x for d in cs]; hs=[d.h for d in cs]
                    xmin=min(xs); xmax=max(xs); hmax=max(hs)
                    xpad=max(1.5,(xmax-xmin)*0.15 if xmax>xmin else 3.0)
                    xmin-=xpad; xmax+=xpad; ymax=max(5.0,hmax*1.12)
                    ml,mr,mt,mb=14*mm,7*mm,8*mm,13*mm
                    W=self.width-ml-mr; H=self.height-mt-mb
                    def X(x): return ml+(x-xmin)/(xmax-xmin)*W
                    def Y(y): return mb+y/ymax*H

                    # Suelo, eje vertical de referencia y escala h [m].
                    c.setStrokeColor(colors.black); c.setLineWidth(0.8)
                    c.line(ml,mb,self.width-mr,mb)
                    c.setFont('Helvetica',6.5); c.drawRightString(self.width-mr,mb-4*mm,'x [m]')
                    c.setDash(3,2); c.line(X(0),mb,X(0),self.height-mt); c.setDash()
                    c.drawString(X(0)+1.5*mm,self.height-mt-2*mm,'eje x=0')
                    c.setFont('Helvetica-Bold',7.5); c.drawString(1.5*mm,self.height-mt,'h [m]')
                    c.setFont('Helvetica',6.5)
                    for yy in range(0,int(ymax)+1,5):
                        py=Y(yy); c.line(ml-1.2*mm,py,ml,py); c.drawRightString(ml-2*mm,py-1.8,str(yy))

                    # Une A-B-C de cada circuito con línea punteada, como en pantalla.
                    c.setDash(2,2); c.setLineWidth(0.55)
                    for cto in sorted({d.circuit for d in cs if d.kind=='phase'}):
                        pts=[]
                        for ph in ('A','B','C'):
                            m=[d for d in cs if d.kind=='phase' and d.circuit==cto and d.phase.upper()==ph]
                            if m: pts.append((X(m[0].x),Y(m[0].h)))
                        for a,b in zip(pts,pts[1:]): c.line(a[0],a[1],b[0],b[1])
                    c.setDash()

                    for d in cs:
                        px,py=X(d.x),Y(d.h); guard=(d.kind=='guard')
                        if guard:
                            c.setLineWidth(1.0); c.circle(px,py,2.1*mm,stroke=1,fill=0)
                            label=f'{d.name} / CG'
                        else:
                            n=max(1,int(d.bundle_n)); rr=2.2*mm if n>1 else 0
                            for k in range(n):
                                a=2*_m.pi*k/n if n>1 else 0
                                c.circle(px+rr*_m.cos(a),py+rr*_m.sin(a),1.25*mm,stroke=1,fill=0)
                            if n>1:
                                c.setDash(1,1); c.circle(px,py,4.5*mm,stroke=1,fill=0); c.setDash()
                            label=f'C{d.circuit}-{d.phase}  n={d.bundle_n}'
                        # Ajusta etiquetas según el lado para reducir solapamientos.
                        right=d.x <= 0
                        tx=px+(3*mm if right else -3*mm)
                        c.setFont('Helvetica-Bold',7)
                        (c.drawString if right else c.drawRightString)(tx,py+2.2*mm,label)
                        c.setFont('Helvetica',6.2)
                        (c.drawString if right else c.drawRightString)(tx,py-2.0*mm,f'x={d.x:.3f}  h={d.h:.3f} m')
                    c.setFont('Helvetica',5.8)
                    c.drawString(1.5*mm,1.5*mm,'Nota: el haz se exagera para hacerlo visible; las coordenadas x/h se representan a escala.')

            doc=SimpleDocTemplate(path,pagesize=landscape(A4),rightMargin=12*mm,leftMargin=12*mm,topMargin=12*mm,bottomMargin=12*mm,
                                  title='Reporte - Parámetros de Secuencia',author='Parámetros de Secuencia')
            styles=getSampleStyleSheet()
            title=ParagraphStyle('ReportTitle',parent=styles['Title'],alignment=TA_CENTER,fontSize=18,leading=22,spaceAfter=8)
            h1=ParagraphStyle('ReportH1',parent=styles['Heading1'],fontSize=14,leading=17,spaceAfter=6)
            mono=ParagraphStyle('ReportMono',parent=styles['Code'],fontName='Courier',fontSize=6.4,leading=7.5)
            note=ParagraphStyle('ReportNote',parent=styles['BodyText'],fontSize=8,leading=10)
            story=[Paragraph('Reporte de Parámetros de Secuencia',title),
                   Paragraph(f'Configuración: {self.example.get()} &nbsp;&nbsp; | &nbsp;&nbsp; ρ terreno: {self.rho.get()} Ω·m &nbsp;&nbsp; | &nbsp;&nbsp; Frecuencia: {self.freq.get()} Hz',note),Spacer(1,5*mm)]
            sections=[('Resultados clave','summary'),('Impedancia de secuencia Z012','seq'),('Impedancia reducida Zabc','red'),('Susceptancia de secuencia','bseq'),('Desarrollo de cálculos','development')]
            for idx,(heading,key) in enumerate(sections):
                story += [Paragraph(heading,h1),Preformatted(self.texts[key].get('1.0','end-1c'),mono),PageBreak()]
            # Geometría: gráfico ancho en la parte superior y resumen debajo.
            # Así se aprovecha el ancho de la hoja y se evita comprimir la tabla a la derecha.
            geom_info=self.geometry_info.get('1.0','end-1c') if hasattr(self,'geometry_info') else ''
            geom_mono=ParagraphStyle('GeometryMono',parent=mono,fontSize=5.4,leading=6.2,spaceBefore=2*mm)
            geom_graph=Table([[GeometryFlowable(getattr(self,'geometry_conductors',[]),263*mm,105*mm)]],
                             colWidths=[265*mm],rowHeights=[107*mm])
            geom_graph.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),
                                            ('LEFTPADDING',(0,0),(-1,-1),1.5*mm),('RIGHTPADDING',(0,0),(-1,-1),1.5*mm),
                                            ('TOPPADDING',(0,0),(-1,-1),1*mm),('BOTTOMPADDING',(0,0),(-1,-1),1*mm),
                                            ('BOX',(0,0),(-1,-1),0.35,colors.lightgrey)]))
            geom_summary=Table([[Preformatted(geom_info,geom_mono)]],colWidths=[265*mm])
            geom_summary.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),
                                              ('LEFTPADDING',(0,0),(-1,-1),2*mm),('RIGHTPADDING',(0,0),(-1,-1),2*mm),
                                              ('TOPPADDING',(0,0),(-1,-1),1.5*mm),('BOTTOMPADDING',(0,0),(-1,-1),1.5*mm),
                                              ('BOX',(0,0),(-1,-1),0.35,colors.lightgrey)]))
            story += [Paragraph('Geometría de la estructura',h1),geom_graph,Spacer(1,2*mm),geom_summary,PageBreak(),Paragraph('Notas',h1),Preformatted(self.texts['notes'].get('1.0','end-1c'),mono)]
            doc.build(story)
            messagebox.showinfo('Reporte PDF','Reporte PDF generado correctamente.\n\n'+path)
        except ImportError:
            messagebox.showerror('Reporte PDF','Falta la librería ReportLab. Ejecute CREAR_EXE.bat nuevamente o instale: pip install reportlab')
        except Exception as e:
            messagebox.showerror('Error al generar PDF',str(e))

    def export_csv(self):
        if not self.last: self.run_calc()
        if not self.last: return
        path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')])
        if not path:return
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f,delimiter=';')
            w.writerow(['GEOMETRIA'])
            w.writerow(['Nombre','Tipo','Circuito','Fase','x_m','h_m','Subconductores','Separacion_m','RMG_ind_mm','RMG_haz_mm'])
            for c in getattr(self,'geometry_conductors',[]):
                w.writerow([c.name,c.kind,c.circuit,c.phase,c.x,c.h,c.bundle_n,c.bundle_spacing_m,c.rmg_mm,equivalent_gmr(c)*1000.0])
            w.writerow([])
            w.writerow(['Matriz','Fila','Columna','Real','Imaginaria'])
            for key in ('Z_natural','Z_reduced','Z_sequence','P_natural','P_reduced','C_reduced','B_reduced','B_sequence'):
                for i,row in enumerate(self.last[key],1):
                    for j,v in enumerate(row,1): w.writerow([key,i,j,v.real,v.imag])
    def save_project(self):
        cs=self.read_rows();
        if not cs:return
        path=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('Proyecto JSON','*.json')])
        if path:
            with open(path,'w',encoding='utf8') as f: json.dump({'rho':self.rho.get(),'freq':self.freq.get(),'bundle_n1':self.bundle_n1.get(),'bundle_d1':self.bundle_d1.get(),'bundle_n2':self.bundle_n2.get(),'bundle_d2':self.bundle_d2.get(),'conductors':[asdict(c) for c in cs]},f,ensure_ascii=False,indent=2)
    def open_project(self):
        path=filedialog.askopenfilename(filetypes=[('Proyecto JSON','*.json')])
        if not path:return
        try:
            with open(path,encoding='utf8') as f:d=json.load(f)
            self.rho.set(str(d.get('rho',600))); self.freq.set(str(d.get('freq',50))); self.bundle_n1.set(str(d.get('bundle_n1',1))); self.bundle_d1.set(str(d.get('bundle_d1',0.45))); self.bundle_n2.set(str(d.get('bundle_n2',1))); self.bundle_d2.set(str(d.get('bundle_d2',0.45))); cs=[Conductor(**x) for x in d['conductors']]; self.draw_table(cs); two=max((c.circuit for c in cs if c.kind=='phase'),default=1)>1; self.bundle2_combo.configure(state='readonly' if two else 'disabled'); self.bundle2_sep.configure(state='normal' if two else 'disabled')
        except Exception as e: messagebox.showerror('Error',str(e))

if __name__=='__main__': App().mainloop()
